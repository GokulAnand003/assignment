import { SET_USER, LOGOUT_USER } from "../actions";
const INITIAL_STATE = {
  userId: null,
};

const authenticationReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case SET_USER:
      return { ...state, userId: state.payload.userId };
    case LOGOUT_USER:
      return { ...INITIAL_STATE };
    default:
      return state;
  }
};

export default authenticationReducer;
