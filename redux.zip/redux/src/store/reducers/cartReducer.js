import { INCREMENT, DECREMENT, ENTERED_ITEM } from "../actions";
const INITIAL_STATE = {
  totalCartItems: 5,
};

const cartReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case INCREMENT:
      return { ...state, totalCartItems: state.totalCartItems + 1 };
    case DECREMENT:
      return { ...state, totalCartItems: state.totalCartItems - 1 };
    case ENTERED_ITEM:
      return { ...state, totalCartItems: action.payload.value };
    default:
      return state;
  }
};

export default cartReducer;
