import { combineReducers } from "redux";
import cartReducer from "./cartReducer";
import authenticationReducer from "./authenticationReducer";

const reducers = combineReducers({ cartReducer, authenticationReducer });
export default reducers;
