import { INCREMENT, DECREMENT, ENTERED_ITEM } from "./action-type";
export const incrementAction = () => {
  return {
    type: INCREMENT,
  };
};

export const decrementAction = () => {
  return {
    type: DECREMENT,
  };
};

export const enteredItemAction = (value) => {
  return {
    type: ENTERED_ITEM,
    payload: { value },
  };
};
