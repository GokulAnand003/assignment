export const INCREMENT = "INCREMENT";
export const DECREMENT = "DECREMENT";
export const ENTERED_ITEM = "ENTERED_ITEM";

export const SET_USER = "SET_USER";
export const LOGOUT_USER = "LOGOUT_USER";
