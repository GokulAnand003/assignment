import { RouterProvider, createBrowserRouter } from "react-router-dom";
import AppLayout from "./components/layouts/appLayout";
import Cart from "./pages/cart";
import Items from "./pages/items";

function App() {
  const router = createBrowserRouter([
    {
      path: "/",
      element: <AppLayout />,
      children: [
        {
          index: true,
          element: <Items />,
        },
        {
          path: "cart",
          element: <Cart pageName="Cart Page" />,
        },
      ],
    },
  ]);
  return <RouterProvider router={router} />;
}

export default App;
