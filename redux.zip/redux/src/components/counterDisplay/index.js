import { useSelector } from "react-redux";
const Counter = () => {
  const counter = useSelector((state) => state.cartReducer.totalCartItems);
  console.log(counter);
  return (
    <>
      <h4>Total: {counter}</h4>
    </>
  );
};

export default Counter;
