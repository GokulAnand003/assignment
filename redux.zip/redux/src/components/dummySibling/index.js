const Sibling = () => {
  console.log("Rendered Sibling Component");
  return <p>Sibling</p>;
};
export default Sibling;
