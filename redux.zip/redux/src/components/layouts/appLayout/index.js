import { Outlet, Link } from "react-router-dom";
import "../../../App.css";
const AppLayout = () => {
  return (
    <div className="App">
      <nav
        style={{
          display: "flex",
          width: "80%",
          justifyContent: "space-evenly",
        }}
      >
        <Link to="/">Items</Link>
        <Link to="/cart">cart</Link>
      </nav>
      <Outlet />
    </div>
  );
};

export default AppLayout;
