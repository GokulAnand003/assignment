import React, { Component } from "react";
import { connect } from "react-redux";
import Sibling from "../components/dummySibling";
import Counter from "../components/counterDisplay";
import {
  incrementAction,
  decrementAction,
  enteredItemAction,
} from "../store/actions";

class Cart extends Component {
  constructor(props) {
    super(props);
    this.state = { pageName: "", enteredItem: 0 };
  }

  static getDerivedStateFromProps(prevProps) {
    console.log("Static Method", prevProps);
    return { pageName: prevProps.pageName };
  }

  onChangeHandler = (e) => {
    const value = e.target.value;
    this.setState({ enteredItem: value });
  };

  onBlurHandler = () => {
    this.props.enteredItem(this.state.enteredItem);
  };

  render() {
    return (
      <React.Fragment>
        <Counter />
        <div>{this.state.pageName}</div>
        <br />
        {/* <h3>Access Locally: {this.props.counter}</h3> */}
        <br />
        <input onChange={this.onChangeHandler} onBlur={this.onBlurHandler} />
        <br />
        <button
          onClick={() => {
            this.props.increment();
          }}
        >
          Add Item
        </button>
        <button
          onClick={() => {
            this.props.decrement();
          }}
        >
          Remove Item
        </button>
        <br />
        <Sibling />
      </React.Fragment>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    counter: state.cartReducer.totalCartItems,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    increment: () => dispatch(incrementAction()),
    decrement: () => dispatch(decrementAction()),
    enteredItem: (value) => dispatch(enteredItemAction(value)),
  };
};
export default connect(null, mapDispatchToProps)(Cart);
