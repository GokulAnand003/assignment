import { useRef } from "react";
import { useDispatch } from "react-redux";
import Counter from "../components/counterDisplay";
import Sibling from "../components/dummySibling";
import {
  decrementAction,
  incrementAction,
  enteredItemAction,
} from "../store/actions";

const Items = () => {
  const dispatch = useDispatch();
  const inputRef = useRef();
  const onBlurHandler = () => {
    dispatch(enteredItemAction(+inputRef.current.value));
    inputRef.current.value = "";
  };
  return (
    <>
      <Counter />
      <div>Items Page</div>
      <button
        onClick={() => {
          dispatch(incrementAction());
        }}
      >
        Add Item
      </button>
      <button
        onClick={() => {
          dispatch(decrementAction());
        }}
      >
        Remove Item
      </button>
      <input ref={inputRef} onBlur={onBlurHandler} />
      <br />
      <Sibling />
    </>
  );
};

export default Items;
