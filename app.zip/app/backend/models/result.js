const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const resultSchema = new Schema({
  validationResult: Number,
  input: String,
  validationType: String,
});

module.exports = mongoose.model("Result", resultSchema);
