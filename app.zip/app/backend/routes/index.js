const express = require("express");
const resultController = require("../controller/index");
const router = express.Router();

router.post("/add-result", resultController.postResult);

module.exports = router;
