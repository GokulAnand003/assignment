const dotenv = require("dotenv");
const express = require("express");
const mongoose = require("mongoose");
const router = require("./routes/index");

dotenv.config();
const MONGODB_URI = process.env.MONGO_DB_URL;

const app = express();

app.use(express.json());
app.use(router);

mongoose
  .connect(MONGODB_URI)
  .then((_result) => {
    console.log("DB connected!");
    app.listen(3001);
    console.log("Application Started");
  })
  .catch((err) => {
    console.log("DB connection Failed!");
    console.log(err);
  });
