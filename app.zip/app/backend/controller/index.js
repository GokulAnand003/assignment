const Result = require("../models/result");

exports.postResult = async (req, res, next) => {
  const { input, result, validationType } = req.body;

  try {
    const value = await Result.create({
      validationResult: result,
      input,
      validationType,
    });
    return res.status(200).json({ data: { id: value._id } });
  } catch (error) {
    return res.status(400).json({ msg: "", error });
  }
};
