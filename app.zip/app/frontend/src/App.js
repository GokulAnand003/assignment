import Password from "./components/Password";
import "./App.css";

function App() {
  return (
    <div className="App">
      <Password />
    </div>
  );
}

export default App;
