import { render, screen, fireEvent } from "@testing-library/react";
import Password from "./Password";

global.fetch = jest.fn(() =>
  Promise.resolve({
    json: () => Promise.resolve({ data: { id: "some-id" } }),
  })
);

describe("validate password screen", () => {
  beforeEach(() => {
    fetch.mockClear();
  });

  test("renders password input", () => {
    render(<Password />);
    const element = screen.getByTestId("input_password");
    expect(element).toBeInTheDocument();
  });

  test("validate password input", () => {
    render(<Password />);
    const element = screen.getByTestId("input_password");
    fireEvent.change(element, { target: { value: "a" } });
    fireEvent.blur(element);
    expect(fetch).toHaveBeenCalledTimes(1);
  });
});
