import { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { passwordValidation } from "../utils/index";
import cn from "./Password.module.css";

function Password() {
  const [value, setValue] = useState("");
  const [strength, setStrength] = useState("");
  const [output, setOutput] = useState("");

  const toastHandler = (message) =>
    toast(message, { autoClose: 3000, position: toast.POSITION.TOP_RIGHT });

  const onChangeHandler = (e) => {
    setValue(e.target.value);
  };
  const onFocusBlurHandler = async () => {
    const { result, wordsToReplace } = passwordValidation(value);
    setStrength(() => (result ? "Strong" : "week"));
    setOutput(wordsToReplace);

    try {
      const response = await fetch("/add-result", {
        method: "PUT",
        body: JSON.stringify({
          input: value,
          result: wordsToReplace,
          validationType: result ? "Strong" : "week",
        }),
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
      });

      if (response.status !== 200) {
        throw new Error("something went wrong!");
      }
      const data = await response.json();
      console.log(data);
      toastHandler("Data saved successfully!");
    } catch (error) {
      toastHandler(error.message);
    }
  };

  let inputClassName = strength === "week" ? cn.week : "";

  return (
    <>
      <div className={cn.card}>
        <input
          value={value}
          id="password"
          onChange={onChangeHandler}
          onBlur={onFocusBlurHandler}
          data-testid="input_password"
          className={inputClassName}
        />
        <p>Strength: {strength}</p>
        <p>Output: {output}</p>
      </div>
      <ToastContainer />
    </>
  );
}

export default Password;
