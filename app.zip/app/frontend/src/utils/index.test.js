import { passwordValidation } from "./index";

describe("password validation utility", () => {
  test.each`
    password      | expected
    ${"Baaabb0"}  | ${{ result: false, wordsToReplace: 1 }}
    ${"Baaba0"}   | ${{ result: true, wordsToReplace: 0 }}
    ${"a"}        | ${{ result: false, wordsToReplace: 5 }}
    ${"aA1"}      | ${{ result: false, wordsToReplace: 3 }}
    ${"1337C0d3"} | ${{ result: true, wordsToReplace: 0 }}
  `(
    "returns validation result $expected when password is $password",
    ({ password, expected }) => {
      const value = passwordValidation(password);
      expect(value).toEqual(expected);
    }
  );
});
