export function passwordValidation(value) {
  let result = false;
  let isRepeat = false;
  let wordsToReplace = 0;
  const strLength = +value.toString().length;
  const validation = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/gm;
  const upperCaseCheck = Boolean(value.match(/[A-Z]/));
  const lowerCaseCheck = Boolean(value.match(/[a-z]/));
  const numberCheck = Boolean(value.match(/[0-9]/));
  if (validation.test(value)) {
    const splitValue = value.split("");

    for (let i = 0; i < splitValue.length; i++) {
      const current = splitValue[i] ?? "";
      const prev = splitValue[i - 1] ?? "";
      const next = splitValue[i + 1] ?? "";
      if (prev === current && current === next) {
        if (!isRepeat) {
          isRepeat = true;
        }
        ++wordsToReplace;
      }
    }
    if (!isRepeat) {
      result = true;
    }
  } else if (strLength < 6 || strLength > 20) {
    wordsToReplace = strLength < 6 ? 6 - strLength : strLength - 20;
  } else if (!upperCaseCheck || !lowerCaseCheck || !numberCheck) {
    wordsToReplace = !upperCaseCheck ? wordsToReplace + 1 : wordsToReplace;
    wordsToReplace = !lowerCaseCheck ? wordsToReplace + 1 : wordsToReplace;
    wordsToReplace = !numberCheck ? wordsToReplace + 1 : wordsToReplace;
  }
  return { result, wordsToReplace };
}
